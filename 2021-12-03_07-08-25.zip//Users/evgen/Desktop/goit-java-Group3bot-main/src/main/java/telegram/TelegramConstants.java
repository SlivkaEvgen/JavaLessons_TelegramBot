package telegram;

public class TelegramConstants {

    public static final String BOT_NAME = "MyFirstGoItJava2021Bot";

    public static final String BOT_TOKEN = "1891322670:AAEeHssBAywpVqKIaNJ7ZlHsIZ5BohhtJiQ";

}