package notification;

public class UserNoActivityTimer {
}
